<template>
	<div class="mx-auto px-10 lg:px-6">
		<slot />
	</div>
</template>
